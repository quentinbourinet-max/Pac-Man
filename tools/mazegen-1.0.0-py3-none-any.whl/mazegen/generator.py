# =========================== GENERATORS CATALOG ============================ #
# Project: A_Maze_ing (42next)
# Authors: elocufie
# Contrib: jferone

from abc import ABC, abstractmethod
from typing import Generator
import random


class BaseGenerator(ABC):
    """Abstract base class for maze generator implementations."""
    @abstractmethod
    def generate(self) -> list[list[int]]:
        """Generate the maze grid as a 4-bit encoded 2D list."""
        pass


# -------------------------- MazeGenerator Package -------------------------- #

# EXCEPTIONS
class MazeError(Exception):
    """Base class for maze-based context errors."""
    pass


class MazeInvalidSizeError(MazeError):
    """Store offending dimensions and build the error message.

    Args:
        width: Offending maze width.
        height: Offending maze height.
    """
    def __init__(self, width: int, height: int):
        self.height = height
        self.width = width
        self.message = (f"Invalid size: {width} x {height}. They must be\
                        higher than 0.")
        super().__init__(self.message)


class MazeInvalidParameterError(MazeError):
    """Store the parameter violation description.

    Args:
            msg: Human-readable description of the violated constraint.
    """
    def __init__(self, msg: str):
        self.msg = msg
        self.message = f"Invalid Parameter: {msg}"
        super().__init__(self.message)


# WARNINGS
class MazeWarning(Warning):
    """Base class for maze-based context warnings."""
    pass


class PatternInvalidSizeWarning(MazeWarning):
    """Return the human-readable warning message."""
    def __init__(self, width: int, height: int):
        """Build the warning message for an undersized grid.

        Args:
            width: Current maze width.
            height: Current maze height.
        """
        self.message = (f"The 42 pattern cannot be included because dimensions"
                        f" ({width} x {height}) are below threshold.")

    def __str__(self) -> str:
        """Return the human-readable warning message."""
        return self.message


class UnrecognizedAlgorithmWarning(MazeWarning):
    """Issued when the requested algorithm name is not in the catalog."""
    def __init__(self, algo_name: str):
        """Build the warning message for an unknown algorithm request.

        Args:
            algo_name: Algorithm name not found in the catalog.
        """
        self.message = (f'No "{algo_name}" algorithm available in generator.'
                        'Default algorithm choosen instead.')

    def __str__(self) -> str:
        """Return the human-readable warning message."""
        return self.message


# ENTRYPOINT
class MazeGenerator(BaseGenerator):
    """Maze Generator. Handles multiple algorithms selection."""

    def __init__(self, width: int, height: int,
                 entry: tuple[int, int],
                 exit_: tuple[int, int], perfect: bool,
                 seed: int | None, asked_algo: str | None):
        """Initialize maze grid, seed RNG, and reserve 42 pattern cells.

        Args:
            width: Number of columns (must be > 0).
            height: Number of rows (must be > 0).
            entry: (col, row) start cell coordinates.
            exit_: (col, row) end cell coordinates, must differ from entry.
            perfect: If True, generate a perfect maze (single solution).
            seed: RNG seed for reproducibility, or None for random.
            asked_algo: Algorithm name string, or None for default.

        Raises:
            MazeInvalidSizeError: If width or height <= 0.
            MazeInvalidParameterError: If entry == exit_ or out of bounds.
        """
        self.width = width
        self.height = height
        self.entry = entry
        self.exit_ = exit_
        self.perfect = perfect
        self.seed = seed
        self.pattern42 = False
        self.width_pattern: int = 7
        self.height_pattern: int = 5
        self.asked_algo = asked_algo

        if width <= 0 or height <= 0:
            raise MazeInvalidSizeError(width, height)
        if entry == exit_:
            raise MazeInvalidParameterError("entry == exit_")
        if not (0 <= entry[0] < width and 0 <= entry[1] < height):
            raise MazeInvalidParameterError("entry out of bounds")
        if not (0 <= exit_[0] < width and 0 <= exit_[1] < height):
            raise MazeInvalidParameterError("exit_ out of bound")
        self.grid: list[list[int]] = [[0xF for _ in range(width)]
                                      for _ in range(height)]
        self.visited: list[list[bool]] = [[False for _ in range(width)]
                                          for _ in range(height)]

        if seed is None:
            seed = random.randint(0, 2**32)
        self.used_seed = seed
        random.seed(self.used_seed)

        if asked_algo is None:
            asked_algo = "default"

        if width >= 11 and height >= 9:
            self.pattern42 = True
        else:
            print(PatternInvalidSizeWarning(width, height))
            self.reserved: set[tuple[int, int]] = set()
            self.pattern42 = False
        if self.pattern42 is True:
            col_start: int = (self.width - self.width_pattern) // 2  # X
            li_start: int = (self.height - self.height_pattern) // 2  # Y

            coord_four: list[tuple[int, int]] = [
                (0, 0), (0, 1), (0, 2), (1, 2), (2, 2), (2, 3), (2, 4)]

            coord_two: list[tuple[int, int]] = [
                (4, 0), (5, 0), (6, 0), (6, 1), (6, 2), (5, 2), (4, 2), (4, 3),
                (4, 4), (5, 4), (6, 4)]

            reserved = set()
            for dx, dy in coord_four + coord_two:  # Decal x & y
                reserved.add((col_start + dx, li_start + dy))

            if self.entry in reserved or self.exit_ in reserved:
                li_start += 1
                reserved.clear()

                for dx, dy in coord_four + coord_two:
                    reserved.add((col_start + dx, li_start + dy))

                if self.entry in reserved or self.exit_ in reserved:
                    li_start -= 2  # DEBUG TEST
                    reserved.clear()
                    for dx, dy in coord_four + coord_two:
                        reserved.add((col_start + dx, li_start + dy))

                    if self.entry in reserved or self.exit_ in reserved:
                        print("[generator] 42 pattern cannot be placed "
                              "(collision with entry/exit). Omitting.")
                        self.pattern42 = False
                        self.reserved = set()
                        return

            self.reserved = reserved
            for dx, dy in coord_four:
                x_reel = col_start + dx
                y_reel = li_start + dy
                self.visited[y_reel][x_reel] = True
            for dx, dy in coord_two:
                x_reel = col_start + dx
                y_reel = li_start + dy
                self.visited[y_reel][x_reel] = True

    # ALGORITHMS CATALOG # - - - - - - - - - - - - - - - - - - - - - - - - - -

    algo_catalog: list[str] = [
                              "dfs",
                              "recursivedivision",
                              ]

    # SLOT 1: DFS Backtracker (default algorithm) - - - - - - - - - - - - - - -

    def _dfs_wall_open(self, x1: int, y1: int, x2: int, y2: int, cx: int,
                       cy: int, nx: int, ny: int) -> bool:
        """Check if the wall between (x1,y1) and (x2,y2) is open.

            Simulates the removal of the wall between current (cx,cy)
            and neighbor (nx,ny).
        """

        x_y_set = {(x1, y1), (x2, y2)}
        c_n_set = {(cx, cy), (nx, ny)}
        if x1 == x2:
            if y1 > y2:
                return not (self.grid[y1][x1] & 0b0001) or x_y_set == c_n_set
            else:
                return not (self.grid[y1][x1] & 0b0100) or x_y_set == c_n_set
        if y1 == y2:
            if x1 > x2:
                return not (self.grid[y1][x1] & 0b1000) or x_y_set == c_n_set
            else:
                return not (self.grid[y1][x1] & 0b0010) or x_y_set == c_n_set
        return False

    def _dfs_all_open_after(self, cells: list[tuple[int, int]],
                            current: tuple[int, int],
                            neighbor: tuple[int, int]) -> bool:

        """Check if all adjacent pairs in a 2x2 square are open.

        Simulates wall removal between current and neighbor.
        Returns True if every adjacent pair in cells is open.
        """

        cx, cy = current
        nx, ny = neighbor

        for i in range(len(cells)):
            x1, y1 = cells[i]
            for j in range(i + 1, len(cells)):
                x2, y2 = cells[j]
                if abs(x1 - x2) + abs(y1 - y2) != 1:
                    continue

                wall_open = self._dfs_wall_open(x1, y1, x2, y2, cx, cy, nx, ny)
                if not wall_open:
                    return False
        return True

    def _dfs_count_open_walls_after(self, nx: int, ny: int,
                                    cx: int, cy: int) -> int:
        """Count how many walls of neighbor (nx,ny) would be open.

        Counts after removing the wall from current (cx,cy).
        Includes walls already opened by previously visited neighbors.
        """

        dirs = [
               (0, -1, 0b0001),  # North
               (1,  0, 0b0010),  # East
               (0,  1, 0b0100),  # South
               (-1, 0, 0b1000),  # West
               ]
        count = 0
        for dx, dy, bit in dirs:
            ax, ay = nx + dx, ny + dy

            if ax == cx and ay == cy:
                count += 1
                continue

            if 0 <= ax < self.width and 0 <= ay < self.height:
                if self.visited[ay][ax]:

                    opp = {0b0001: 0b0100, 0b0100: 0b0001,
                           0b0010: 0b1000, 0b1000: 0b0010}
                    opp_bit = opp[bit]
                    if not (self.grid[ay][ax] & opp_bit):
                        count += 1
        return count

    def _dfs_check_corridors(self, current: tuple[int, int],
                             neighbor: tuple[int, int]) -> bool:
        """
         Return True if removing the wall between current and neighbor
        is allowed by the corridor constraint (no fully open 2x2 area).
        """

        cx, cy = current
        nx, ny = neighbor

        if self._dfs_count_open_walls_after(nx, ny, cx, cy) >= 4:
            return False

        for row in range(min(cy, ny) - 1, max(cy, ny) + 1):
            for col in range(min(cx, nx) - 1, max(cx, nx) + 1):
                cells = [
                        (col, row),
                        (col + 1, row),
                        (col, row + 1),
                        (col + 1, row + 1)
                        ]
                if not all(
                          0 <= c < self.width and 0 <= r < self.height
                          for c, r in cells
                          ):
                    continue
                if self._dfs_all_open_after(cells, current, neighbor):
                    return False
        return True

    def _dfs_generator(
                      self, steps_per_frame: int
                      ) -> Generator[list[list[int]], None, None]:
        """Yield intermediate grid states during DFS generation."""
        stack = [self.entry]
        x, y = self.entry
        self.visited[y][x] = True
        card_point = [
                     (0, -1, 0b0001, 0b0100),
                     (+1, 0, 0b0010, 0b1000),
                     (0, +1, 0b0100, 0b0001),
                     (-1, 0, 0b1000, 0b0010),
                     ]
        step_count = 0
        while stack:
            cx, cy = stack[-1]
            neighbors = []
            for dx, dy, b_h, b_n in card_point:
                nx, ny = cx + dx, cy + dy
                if (0 <= nx < self.width and 0 <= ny < self.height
                        and not self.visited[ny][nx]
                        and (nx, ny) not in self.reserved):
                    if self._dfs_check_corridors((cx, cy), (nx, ny)):
                        neighbors.append((nx, ny, b_h, b_n))
            if neighbors:
                nx, ny, b_here, b_neigh = random.choice(neighbors)
                self.grid[cy][cx] &= ~b_here
                self.grid[ny][nx] &= ~b_neigh
                self.visited[ny][nx] = True
                stack.append((nx, ny))
                step_count += 1
                if step_count % steps_per_frame == 0:
                    yield self.grid
            else:
                stack.pop()

        if not self.perfect:
            LOOP_FACTOR = 0.10
            N = max(1, int(self.width * self.height * LOOP_FACTOR))
            walls = []
            for r in range(self.height):
                for c in range(self.width):
                    if c + 1 < self.width:
                        if (c, r) not in self.reserved and \
                                (c + 1, r) not in self.reserved:
                            if self.grid[r][c] & 0b0010:
                                walls.append(((c, r), (c + 1, r),
                                              0b0010, 0b1000))
                    if r + 1 < self.height:
                        if (c, r) not in self.reserved and \
                                (c, r + 1) not in self.reserved:
                            if self.grid[r][c] & 0b0100:
                                walls.append(((c, r), (c, r + 1),
                                              0b0100, 0b0001))
            random.shuffle(walls)
            count = 0
            for (ca, cb, ba, bb) in walls:
                if count >= N:
                    break
                if self._dfs_check_corridors(ca, cb):
                    ax, ay = ca
                    bx, by = cb
                    self.grid[ay][ax] &= ~ba
                    self.grid[by][bx] &= ~bb
                    count += 1
        yield self.grid

    def dfs_backtracker(self) -> list[list[int]]:   # ALGORITHM ENTRYPOINT #
        """
        Generate the maze grid using DFS backtracker algorithm (default).

        If perfect=False, adds extra loops after DFS by removing
        additional walls (LOOP_FACTOR = 10% of total cells).
        Returns the grid as list[list[int]], 4-bit encoding per cell.
        """

        start = self.entry

        stack = [start]
        x, y = start
        self.visited[y][x] = True

        card_point = [
                     (0, -1, 0b0001, 0b0100),  # North
                     (+1, 0, 0b0010, 0b1000),  # East
                     (0, +1, 0b0100, 0b0001),  # South
                     (-1, 0, 0b1000, 0b0010),  # West
                     ]

        while (stack):
            cx, cy = stack[-1]

            neighbors = []
            for dx, dy, b_h, b_n in card_point:
                nx = cx + dx
                ny = cy + dy

                if 0 <= nx < self.width and 0 <= ny < self.height:
                    if self.visited[ny][nx] is False:
                        if self._dfs_check_corridors((cx, cy),
                                                     (nx, ny)) is True:
                            neighbors.append((nx, ny, b_h, b_n))
            if neighbors:
                nx, ny, b_here, b_neigh = random.choice(neighbors)

                self.grid[cy][cx] &= ~b_here
                self.grid[ny][nx] &= ~b_neigh

                self.visited[ny][nx] = True
                stack.append((nx, ny))

            else:
                stack.pop()

        if not self.perfect:
            LOOP_FACTOR = 0.10
            N = max(1, int(self.width * self.height * LOOP_FACTOR))
            walls = []
            for r in range(self.height):
                for c in range(self.width):
                    if c + 1 < self.width:
                        if (c, r) not in self.reserved and (c+1, r) not in\
                             self.reserved:
                            if self.grid[r][c] & 0b0010:
                                walls.append(((c, r), (c + 1, r), 0b0010,
                                              0b1000))
                    if r + 1 < self.height:
                        if (c, r) not in self.reserved and (c, r + 1) not in\
                          self.reserved:
                            if self.grid[r][c] & 0b0100:
                                walls.append(((c, r), (c, r + 1), 0b0100,
                                              0b0001))
            random.shuffle(walls)

            count = 0
            for (ca, cb, ba, bb) in walls:
                if count >= N:
                    break
                if self._dfs_check_corridors(ca, cb):
                    ax, ay = ca
                    bx, by = cb
                    self.grid[ay][ax] &= ~ba
                    self.grid[by][bx] &= ~bb
                    count += 1

        return self.grid

    # SLOT 2: Recursive Division (bonus algorithm) - - - - - - - - - - - - - -

    def _rd_open_interiors(self) -> None:
        """Open all interior walls, preserve borders and reserved cells."""
        for row in range(self.height):
            for col in range(self.width):
                cell = 0
                if row == 0:
                    cell |= 0b0001
                if col == self.width - 1:
                    cell |= 0b0010
                if row == self.height - 1:
                    cell |= 0b0100
                if col == 0:
                    cell |= 0b1000
                self.grid[row][col] = cell
        for rx, ry in self.reserved:
            self.grid[ry][rx] = 0xF

    def _rd_add_wall_h(self, x: int, y: int, w: int, passage: int) -> bool:
        """Add horizontal wall at row y across cols x..x+w, skip passage.

        Returns:
            True if at least one wall segment was actually placed."""
        placed: bool = False
        for col in range(x, x + w):
            if col == passage:
                continue
            if (col, y) in self.reserved or (col, y - 1) in self.reserved:
                continue
            self.grid[y][col] |= 0b0001
            self.grid[y - 1][col] |= 0b0100
            placed = True
        return placed

    def _rd_add_wall_v(self, x: int, y: int, h: int, passage: int) -> bool:
        """Add vertical wall at col x across rows y..y+h, skip passage.

        Returns:
            True if at least one wall segment was actually placed."""
        placed: bool = False
        for row in range(y, y + h):
            if row == passage:
                continue
            if (x, row) in self.reserved or (x - 1, row) in self.reserved:
                continue
            self.grid[row][x] |= 0b1000
            self.grid[row][x - 1] |= 0b0010
            placed = True
        return placed

    def _rd_divide_gen(
                      self, x: int, y: int, w: int, h: int
                      ) -> Generator[list[list[int]], None, None]:
        """Yield intermediate grid states during recursive division.

        Retries wall placement up to 5 times if reserved cells prevent
        any wall segment from being placed. Accepts degenerate division
        (no wall placed) if all attempts fail.
        """
        if w <= 1 or h <= 1:
            return
        if h > w:
            orientation = 'H'
        elif w > h:
            orientation = 'V'
        else:
            orientation = random.choice(['H', 'V'])

        max_attempts: int = min(5, (h - 1) if orientation == 'H' else (w - 1))

        if orientation == 'H':
            wall_row: int = random.randint(1, h - 1)
            for _ in range(max_attempts):
                valid = ([col for col in range(x, x + w)
                         if (col, y + wall_row) not in self.reserved
                         and (col, y + wall_row - 1) not in self.reserved])
                if not valid:
                    valid = list(range(x, x + w))
                passage = random.choice(valid)
                if self._rd_add_wall_h(x, y + wall_row, w, passage):
                    break
                wall_row = random.randint(1, h - 1)
            yield self.grid
            yield from self._rd_divide_gen(x, y, w, wall_row)
            yield from self._rd_divide_gen(x, y + wall_row, w, h - wall_row)
        else:
            wall_col: int = random.randint(1, w - 1)
            for _ in range(max_attempts):
                valid = ([row for row in range(y, y + h)
                         if (x + wall_col, row) not in self.reserved
                         and (x + wall_col - 1, row) not in self.reserved])
                if not valid:
                    valid = list(range(y, y + h))
                passage = random.choice(valid)
                if self._rd_add_wall_v(x + wall_col, y, h, passage):
                    break
                wall_col = random.randint(1, w - 1)
            yield self.grid
            yield from self._rd_divide_gen(x, y, wall_col, h)
            yield from self._rd_divide_gen(x + wall_col, y, w - wall_col, h)

    def _rd_wall_open(self, x1: int, y1: int, x2: int, y2: int, cx: int,
                      cy: int, nx: int, ny: int) -> bool:
        """
            Check if the wall between (x1,y1) and (x2,y2) is open.

            Simulates the removal of the wall between current (cx,cy)
            and neighbor (nx,ny).
        """

        x_y_set = {(x1, y1), (x2, y2)}
        c_n_set = {(cx, cy), (nx, ny)}
        if x1 == x2:
            if y1 > y2:
                return not (self.grid[y1][x1] & 0b0001) or x_y_set == c_n_set
            else:
                return not (self.grid[y1][x1] & 0b0100) or x_y_set == c_n_set
        if y1 == y2:
            if x1 > x2:
                return not (self.grid[y1][x1] & 0b1000) or x_y_set == c_n_set
            else:
                return not (self.grid[y1][x1] & 0b0010) or x_y_set == c_n_set
        return False

    def _rd_all_open_after(self, cells: list[tuple[int, int]],
                           current: tuple[int, int],
                           neighbor: tuple[int, int]) -> bool:
        """
        Check if all adjacent pairs in a 2x2 square are open.

        Simulates wall removal between current and neighbor.
        Returns True if every adjacent pair in cells is open.
        """

        cx, cy = current
        nx, ny = neighbor

        for i in range(len(cells)):
            x1, y1 = cells[i]
            for j in range(i + 1, len(cells)):
                x2, y2 = cells[j]
                if abs(x1 - x2) + abs(y1 - y2) != 1:
                    continue

                wall_open = self._rd_wall_open(x1, y1, x2, y2, cx, cy, nx, ny)
                if not wall_open:
                    return False
        return True

    def _rd_check_corridors(self, current: tuple[int, int],
                            neighbor: tuple[int, int]) -> bool:
        """
         Return True if removing the wall between current and neighbor
        is allowed by the corridor constraint (no fully open 2x2 area).
        """

        cx, cy = current
        nx, ny = neighbor

        for row in range(min(cy, ny) - 1, max(cy, ny) + 1):
            for col in range(min(cx, nx) - 1, max(cx, nx) + 1):
                cells = [
                        (col, row),
                        (col + 1, row),
                        (col, row + 1),
                        (col + 1, row + 1)
                        ]
                if not all(
                          0 <= c < self.width and 0 <= r < self.height
                          for c, r in cells
                          ):
                    continue
                if self._rd_all_open_after(cells, current, neighbor):
                    return False
        return True

    def _rd_fix_isolated_cells(self) -> None:
        """Reconnect cells isolated after recursive division.

        Runs BFS from entry to identify all reachable cells. Then
        iteratively opens walls from unreached cells toward reached
        neighbors until all non-reserved cells are connected.

        Each wall opening is first validated by _rd_check_corridors
        to preserve the anti-2x2 constraint. If no direction passes
        the check, the first available candidate is forced to guarantee
        connectivity (fallback, accepted exceptionally).
        """
        reached: set[tuple[int, int]] = set()
        queue: list[tuple[int, int]] = [self.entry]
        reached.add(self.entry)
        card = [
               (0, -1, 0b0001, 0b0100),
               (+1, 0, 0b0010, 0b1000),
               (0, +1, 0b0100, 0b0001),
               (-1, 0, 0b1000, 0b0010),
               ]
        while queue:
            cx, cy = queue.pop(0)
            for dx, dy, bit_here, bit_neigh in card:
                nx, ny = cx + dx, cy + dy
                if (0 <= nx < self.width and 0 <= ny < self.height
                        and (nx, ny) not in reached
                        and (nx, ny) not in self.reserved
                        and not (self.grid[cy][cx] & bit_here)):
                    reached.add((nx, ny))
                    queue.append((nx, ny))

        changed = True
        while changed:
            changed = False
            for row in range(self.height):
                for col in range(self.width):
                    if (col, row) in reached or (col, row) in self.reserved:
                        continue
                    candidates: list[tuple[int, int, int, int]] = []
                    for dx, dy, bit_here, bit_neigh in card:
                        nx, ny = col + dx, row + dy
                        if (nx, ny) in reached:
                            candidates.append((nx, ny, bit_here, bit_neigh))
                    if not candidates:
                        continue
                    opened: bool = False
                    for nx, ny, bit_here, bit_neigh in candidates:
                        if self._rd_check_corridors((col, row), (nx, ny)):
                            self.grid[row][col] &= ~bit_here
                            self.grid[ny][nx] &= ~bit_neigh
                            reached.add((col, row))
                            changed = True
                            opened = True
                            break
                    if not opened:
                        nx, ny, bit_here, bit_neigh = candidates[0]
                        self.grid[row][col] &= ~bit_here
                        self.grid[ny][nx] &= ~bit_neigh
                        reached.add((col, row))
                        changed = True

    def _rd_generator(
                     self
                     ) -> Generator[list[list[int]], None, None]:
        """Yield intermediate grid states during recursive division."""
        self._rd_open_interiors()
        yield self.grid
        yield from self._rd_divide_gen(0, 0, self.width, self.height)
        card_seal = [
                    (0, -1, 0b0001, 0b0100),
                    (+1, 0, 0b0010, 0b1000),
                    (0, +1, 0b0100, 0b0001),
                    (-1, 0, 0b1000, 0b0010),
                    ]
        for rx, ry in self.reserved:
            for dx, dy, _b_res, b_neigh in card_seal:
                nx, ny = rx + dx, ry + dy
                if 0 <= nx < self.width and 0 <= ny < self.height:
                    if (nx, ny) not in self.reserved:
                        self.grid[ny][nx] |= b_neigh
        self._rd_fix_isolated_cells()
        yield self.grid

    def recursive_division(self) -> list[list[int]]:  # ALGORITHM ENTRYPOINT #
        """
        Generate the maze grid using Recursive Division algorithm.

        Starts from a fully open grid (borders only), then recursively
        subdivides rectangles by adding walls with one passage each.
        Reserved '42' pattern cells are never walled over.

        If perfect=False, adds extra loops after division by removing
        additional walls (LOOP_FACTOR = 10% of total cells).
        Returns the grid as list[list[int]], 4-bit encoding per cell.
        """
        # Start: Opens all walls before closing
        self._rd_open_interiors()
        for _ in self._rd_divide_gen(0, 0, self.width, self.height):
            pass

        # Seal reserved boundaries: close walls between reserved and neighbors
        card_seal = [
                    (0, -1, 0b0001, 0b0100),  # North
                    (+1, 0, 0b0010, 0b1000),  # East
                    (0, +1, 0b0100, 0b0001),  # South
                    (-1, 0, 0b1000, 0b0010),  # West
                    ]
        for rx, ry in self.reserved:
            for dx, dy, _b_res, b_neigh in card_seal:
                nx, ny = rx + dx, ry + dy
                if 0 <= nx < self.width and 0 <= ny < self.height:
                    if (nx, ny) not in self.reserved:
                        self.grid[ny][nx] |= b_neigh

        self._rd_fix_isolated_cells()

        if not self.perfect:
            LOOP_FACTOR = 0.10
            N = max(1, int(self.width * self.height * LOOP_FACTOR))
            walls = []
            for r in range(self.height):
                for c in range(self.width):
                    if c + 1 < self.width:
                        if (c, r) not in self.reserved and \
                                (c + 1, r) not in self.reserved:
                            if self.grid[r][c] & 0b0010:
                                walls.append(((c, r), (c + 1, r), 0b0010,
                                              0b1000))
                    if r + 1 < self.height:
                        if (c, r) not in self.reserved and \
                                (c, r + 1) not in self.reserved:
                            if self.grid[r][c] & 0b0100:
                                walls.append(((c, r), (c, r + 1), 0b0100,
                                              0b0001))
            random.shuffle(walls)
            count = 0
            for (ca, cb, ba, bb) in walls:
                if count >= N:
                    break
                if self._rd_check_corridors(ca, cb):
                    ax, ay = ca
                    bx, by = cb
                    self.grid[ay][ax] &= ~ba
                    self.grid[by][bx] &= ~bb
                    count += 1

        return self.grid

    # ENTRYPOINT # ------------------------------------------------------------

    def generate(self) -> list[list[int]]:
        """Runs the selected or default algorithm for MazeGenerator.

        Returns:
            list[list[int]] at each animation frame.
        """

        algo_name: str = (self.asked_algo if self.asked_algo
                          is not None else "default")

        if algo_name not in self.algo_catalog:
            print(UnrecognizedAlgorithmWarning(algo_name))
            algo_name = "default"

        match algo_name:
            case "dfs":
                self.processed_algorithm = "DFS Backtracker"
                return self.dfs_backtracker()
            case "recursivedivision":
                self.processed_algorithm = "Recursive Division"
                return self.recursive_division()
            case _:
                self.processed_algorithm = "DFS Backtracker"
                return self.dfs_backtracker()

    def generate_animated(self) -> Generator[list[list[int]], None, None]:

        """Return a generator yielding intermediate grid states.

        Yields grid snapshots during generation for animation.
        Frame count is capped at 150 for a ~5-second display budget.

        Returns:
            Generator yielding list[list[int]] at each animation frame.
        """
        algo_name: str = (self.asked_algo if self.asked_algo
                          is not None else "default")
        if algo_name not in self.algo_catalog:
            print(UnrecognizedAlgorithmWarning(algo_name))
            algo_name = "default"

        total: int = self.width * self.height
        steps_per_frame: int = max(1, total // 150)

        match algo_name:
            case "dfs":
                self.processed_algorithm = "DFS Backtracker"
                yield from self._dfs_generator(steps_per_frame)
            case "recursivedivision":
                self.processed_algorithm = "Recursive Division"
                yield from self._rd_generator()
            case _:
                self.processed_algorithm = "DFS Backtracker"
                yield from self._dfs_generator(steps_per_frame)

# ------------------------ End of MazeGenerator Pack ------------------------ #

# =========================== END OF GENERATOR.PY =========================== #
