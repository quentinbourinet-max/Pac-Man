# ============================= SOLVERS CATALOG ============================= #
# Project: A_Maze_ing (42next)
# Authors: elocufie
# Contrib: jferone

from collections import deque


# --------------------------- maze_solver Package --------------------------- #

# EXCEPTIONS
class SolverNoPathError(Exception):
    """Record the unreachable entry/exit pair and build the message.

    Args:
        entry: (col, row) entry coordinates.
        exit_: (col, row) exit coordinates.
    """

    def __init__(self, entry: tuple[int, int], exit_: tuple[int, int]):
        self.message = f"No path found from {entry} to {exit_}"
        super().__init__(self.message)


# ENTRYPOINT
def maze_solver(
               grid: list[list[int]],
               entry: tuple[int, int],
               exit_: tuple[int, int]
               ) -> tuple[list[tuple[int, int]], str]:
    """
    Find the shortest path from entry to exit using BFS.

    Reads the maze grid encoded as list[list[int]] where each cell
    is a 4-bit integer (bit0=North, bit1=East, bit2=South, bit3=West).
    A wall is closed if the corresponding bit is 1, open if 0.

    Args:
        grid: 2D list of integers, grid[row][col], produced by MazeGenerator.
        entry: (col, row) coordinates of the starting cell.
        exit_: (col, row) coordinates of the target cell.

    Returns:
        path_coords: ordered list of (col, row) from entry to exit_.
        path_str: string of directions N/E/S/W (e.g. 'EESSWN').

    Raises:
        SolverNoPathError: if no path exists between entry and exit_.
    """

    height = len(grid)
    width = len(grid[0])
    card_point = [
                (0, -1, 0b0001, 'N'),  # North
                (+1, 0, 0b0010, 'E'),  # East
                (0, +1, 0b0100, 'S'),  # South
                (-1, 0, 0b1000, 'W'),  # West
                 ]
    queue = deque([entry])
    came_from: dict[tuple[int, int], tuple[int, int] | None] = {entry: None}

    while queue:
        current = queue.popleft()

        if current == exit_:
            path_coords = []
            step: tuple[int, int] | None = exit_

            while step is not None:
                path_coords.append(step)
                step = came_from[step]

            path_coords.reverse()

            path_str = ""
            for i in range(len(path_coords) - 1):
                cx, cy = path_coords[i]
                nx, ny = path_coords[i + 1]
                if nx > cx:
                    path_str += 'E'
                elif nx < cx:
                    path_str += 'W'
                elif ny > cy:
                    path_str += 'S'
                elif ny < cy:
                    path_str += 'N'
            return path_coords, path_str

        cx, cy = current
        for dx, dy, bit, _letter in card_point:
            nx, ny = cx + dx, cy + dy
            if (0 <= nx < width and 0 <= ny < height
                and (nx, ny) not in came_from and not
               (grid[cy][cx] & bit)):
                came_from[(nx, ny)] = current
                queue.append((nx, ny))

    raise SolverNoPathError(entry, exit_)

# ------------------------- End of maze_solver Pack ------------------------- #

# ============================= END OF SOLVER.PY ============================ #
